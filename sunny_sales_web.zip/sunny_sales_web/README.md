# Sunny Sales - Web

Aplicação web em React utilizando Vite.

## Desenvolvimento

```bash
npm install
npm run dev
```

Defina `VITE_BASE_URL` para apontar para o backend (por omissão `http://localhost:8000`).
